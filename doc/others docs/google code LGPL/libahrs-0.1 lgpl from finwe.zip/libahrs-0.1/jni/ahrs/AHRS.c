//=====================================================================================================
// AHRS.c
//
// Version history:
//
// 15th August 2012 Heikki Keranen, Finwe Ltd.
//     Protection against division by zero.
//     Modifications for converting the code into dynamically linked library
//	   (DLL) to make possible to use under LGPL with other software.
//
// 25th August 2010 S.O.H. Madgwick
//     Original version, published in
//     http://code.google.com/p/imumargalgorithm30042010sohm/
//     under LGPL
//
//=====================================================================================================
// Description:
//
// Quaternion implementation of the 'DCM filter' [Mayhony et al].  Incorporates the magnetic distortion
// compensation algorithms from my filter [Madgwick] which eliminates the need for a reference
// direction of flux (bx bz) to be predefined and limits the effect of magnetic distortions to yaw
// axis only.
//
// User must define 'halfT' as the (sample period / 2), and the filter gains 'Kp' and 'Ki'.
//
// Global variables 'q0', 'q1', 'q2', 'q3' are the quaternion elements representing the estimated
// orientation.  See my report for an overview of the use of quaternions in this application.
//
// User must call 'AHRSupdate()' every sample period and parse calibrated gyroscope ('gx', 'gy', 'gz'),
// accelerometer ('ax', 'ay', 'ay') and magnetometer ('mx', 'my', 'mz') data.  Gyroscope units are
// radians/second, accelerometer and magnetometer units are irrelevant as the vector is normalised.
//
//=====================================================================================================

//----------------------------------------------------------------------------------------------------
// Header files

#include "AHRS.h"
#include <math.h>

//----------------------------------------------------------------------------------------------------
// Definitions



//---------------------------------------------------------------------------------------------------
// Variable definitions

//float q0 = 1, q1 = 0, q2 = 0, q3 = 0;	// quaternion elements representing the estimated orientation
//float exInt = 0, eyInt = 0, ezInt = 0;	// scaled integral error

//====================================================================================================
// Function
//====================================================================================================

void AHRSupdate(struct AHRS_state* ahrs, float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz) {
	float norm;
	float hx, hy, hz, bx, bz;
	float vx, vy, vz, wx, wy, wz;
	float ex, ey, ez;

	// auxiliary variables to reduce number of repeated operations
	float q0q0 = ahrs->q0*ahrs->q0;
	float q0q1 = ahrs->q0*ahrs->q1;
	float q0q2 = ahrs->q0*ahrs->q2;
	float q0q3 = ahrs->q0*ahrs->q3;
	float q1q1 = ahrs->q1*ahrs->q1;
	float q1q2 = ahrs->q1*ahrs->q2;
	float q1q3 = ahrs->q1*ahrs->q3;
	float q2q2 = ahrs->q2*ahrs->q2;
	float q2q3 = ahrs->q2*ahrs->q3;
	float q3q3 = ahrs->q3*ahrs->q3;
	
	// normalise the measurements
	norm = sqrt(ax*ax + ay*ay + az*az);
	if (!norm) return;
	ax = ax / norm;
	ay = ay / norm;
	az = az / norm;
	norm = sqrt(mx*mx + my*my + mz*mz);
	if (!norm) return;
	mx = mx / norm;
	my = my / norm;
	mz = mz / norm;         
	
	// compute reference direction of flux
	hx = 2*mx*(0.5 - q2q2 - q3q3) + 2*my*(q1q2 - q0q3) + 2*mz*(q1q3 + q0q2);
	hy = 2*mx*(q1q2 + q0q3) + 2*my*(0.5 - q1q1 - q3q3) + 2*mz*(q2q3 - q0q1);
	hz = 2*mx*(q1q3 - q0q2) + 2*my*(q2q3 + q0q1) + 2*mz*(0.5 - q1q1 - q2q2);         
	bx = sqrt((hx*hx) + (hy*hy));
	bz = hz;        
	
	// estimated direction of gravity and flux (v and w)
	vx = 2*(q1q3 - q0q2);
	vy = 2*(q0q1 + q2q3);
	vz = q0q0 - q1q1 - q2q2 + q3q3;
	wx = 2*bx*(0.5 - q2q2 - q3q3) + 2*bz*(q1q3 - q0q2);
	wy = 2*bx*(q1q2 - q0q3) + 2*bz*(q0q1 + q2q3);
	wz = 2*bx*(q0q2 + q1q3) + 2*bz*(0.5 - q1q1 - q2q2);  
	
	// error is sum of cross product between reference direction of fields and direction measured by sensors
	ex = (ay*vz - az*vy) + (my*wz - mz*wy);
	ey = (az*vx - ax*vz) + (mz*wx - mx*wz);
	ez = (ax*vy - ay*vx) + (mx*wy - my*wx);
	
	// integral error scaled integral gain
	ahrs->exInt = ahrs->exInt + ex*ahrs->Ki;
	ahrs->eyInt = ahrs->eyInt + ey*ahrs->Ki;
	ahrs->ezInt = ahrs->ezInt + ez*ahrs->Ki;
	
	// adjusted gyroscope measurements
	gx = gx + ahrs->Kp*ex + ahrs->exInt;
	gy = gy + ahrs->Kp*ey + ahrs->eyInt;
	gz = gz + ahrs->Kp*ez + ahrs->ezInt;
	
	// integrate quaternion rate and normalise
	ahrs->q0 = ahrs->q0 + (-ahrs->q1*gx - ahrs->q2*gy - ahrs->q3*gz)*ahrs->halfT;
	ahrs->q1 = ahrs->q1 + (ahrs->q0*gx + ahrs->q2*gz - ahrs->q3*gy)*ahrs->halfT;
	ahrs->q2 = ahrs->q2 + (ahrs->q0*gy - ahrs->q1*gz + ahrs->q3*gx)*ahrs->halfT;
	ahrs->q3 = ahrs->q3 + (ahrs->q0*gz + ahrs->q1*gy - ahrs->q2*gx)*ahrs->halfT;
	
	// normalise quaternion
	norm = sqrt(ahrs->q0*ahrs->q0 + ahrs->q1*ahrs->q1 + ahrs->q2*ahrs->q2 + ahrs->q3*ahrs->q3);
	if (!norm) return;
	ahrs->q0 = ahrs->q0 / norm;
	ahrs->q1 = ahrs->q1 / norm;
	ahrs->q2 = ahrs->q2 / norm;
	ahrs->q3 = ahrs->q3 / norm;
}

//====================================================================================================
// END OF CODE
//====================================================================================================
