//=====================================================================================================
// AHRS.h
//
// Version history:
//
// 15th August 2012 Heikki Keranen, Finwe Ltd.
//     Protection against division by zero.
//     Modifications for converting the code into dynamically linked library
//	   (DLL) to make possible to use under LGPL with other software.
//
// 25th August 2010 S.O.H. Madgwick
//     Original version, published in
//     http://code.google.com/p/imumargalgorithm30042010sohm/
//     under LGPL
//=====================================================================================================
//
// See AHRS.c file for description.
// 
//=====================================================================================================
#ifndef AHRS_h
#define AHRS_h

//----------------------------------------------------------------------------------------------------
// Variable declaration


struct AHRS_state {
	// quaternion elements representing the estimated orientation
	float q0;
	float q1;
	float q2;
	float q3;
	float Kp; 	 // 2.0f			// proportional gain governs rate of convergence to accelerometer/magnetometer
	float Ki; 	 // 0.005f		// integral gain governs rate of convergence of gyroscope biases
	float halfT; // 0.5f		// half the sample period
	float exInt;
	float eyInt;
	float ezInt;
};


//extern float q0, q1, q2, q3;

//---------------------------------------------------------------------------------------------------
// Function declaration

void AHRSupdate(struct AHRS_state* ahrs, float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz);

#endif
//=====================================================================================================
// End of file
//=====================================================================================================
