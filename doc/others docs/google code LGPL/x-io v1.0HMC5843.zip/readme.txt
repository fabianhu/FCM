******************************************************
x-io v1.0HMC5843.hex  read me
******************************************************

x-io v1.0HMC5843.hex is an unofficial firmware release for the x-io Board v1.0 that provides interface to the Honeywell HMC5843 tri-axis magnetometer through the x-io Board COMMS header.

The firmware is uploaded to the x-io Board in the same way as official x-io board firmware update.

Connections:
- COM0 = SCL
- COM1 = SDA
- Both SDA and SCL are required to be, separately, pulled to 3.3V via pull-up resistors.  10kOhms has been found to be sufficient.

Operation:	
- The HMC5843 is configured for maximum update rate and a +-1 Ga range.  The x, y and z axis data is sorted in the comms data array elements 0 to 5.
- The x-io Board STATUS LED no longer functions normally and is instead used to indicate comms between the HMC5843 and the x-io Board.  Rapid OK flashes indicate all is OK, slower error flashes indicate comms have broken down.
- If comms between the x-io Board and HMC5843 breaks down (e.g. through poor connections), the x-io will freeze up.  Once comms are re-established, there is a chance that the HMC5843 have entered a state when comms function correctly but sensor values are not updated.  Resetting the x-io Board (pull reset pin to GND) will solve this problem.


******************************************************
